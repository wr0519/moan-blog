### README

This directory contains the source code for the second exercise of chapter 4. In this exercise, you will build two Docker images

 - Using the standard build process using python:3 as the base image (present in [docker-multi-stage/standard-build](docker-multi-stage/standard-build) directory. 
 - Using Multi-Stage builds (present [docker-multi-stage/multistage-build](docker-multi-stage/multistage-build) directory. 
