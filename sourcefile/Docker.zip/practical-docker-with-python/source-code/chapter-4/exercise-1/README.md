### README

This directory contains the source code for the first exercise of chapter 4. At the start of the chapter, we introduced a simple Dockerfile that did not build due to syntax errors. Here, you’ll fix the Dockerfile and add some of the instructions that you learned about in this chapter.
