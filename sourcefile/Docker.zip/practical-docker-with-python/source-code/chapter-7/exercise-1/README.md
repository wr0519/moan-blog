### README

This exercise contains the source code for the first exercise of chapter 7. In this exercise, we will build a multi-container application consisting of a container for the MySQL database and another container for Adminer, a popular Web UI for MySQL. Since we already have prebuilt images for MySQL and Adminer, we won’t have to build them.
