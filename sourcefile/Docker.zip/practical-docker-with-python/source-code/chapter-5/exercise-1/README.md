### README

This directory contains the source code for the first exercise of chapter 5. In this exercise, we build an nginx Docker image with a Docker volume attached, which contains a custom nginx configuration. Toward the second part of the exercise, we will attach a bind mount and a volume containing a static web page and a custom nginx configuration. The intent of the exercise is help the readers understand how to leverage volumes and bind mounts to make local development easy.
